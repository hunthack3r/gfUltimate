# gf-patterns
Some of the gf patterns which i use while hunting 

contribution and suggestions are always welcome at https://twitter.com/Nitinydv14.

# Thanks to all the authors for publishing these patterns
